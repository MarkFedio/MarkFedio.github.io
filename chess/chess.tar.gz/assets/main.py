import asyncio

import pygame
from pygame import *
import sys
import traceback

from constants import *
import chess_board

pygame.init()

frame_clock = time.Clock()

print(f"len argv: {len(sys.argv)}")
if len(sys.argv) == 2:
    mode = int(sys.argv[1])
else:
    mode = 1

screen = display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
screen.fill(WHITE)
display.set_caption("Chess")

_init_error = None
try:
    board = chess_board.Board(mode)
except Exception as _e:
    _init_error = traceback.format_exc()
    print(f"INIT ERROR: {_init_error}")
    board = None

fps_list = []
fps_list_whole = []


async def main():
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                if fps_list_whole:
                    print(f"entire fps average: {sum(fps_list_whole)/len(fps_list_whole)}")
                pygame.quit()
                sys.exit()
            else:
                if board is not None:
                    board.handle_event(event, screen)

        if board is None:
            # Show error message on screen
            screen.fill((20, 20, 20))
            err_font = pygame.font.Font(None, 20)
            y = 10
            for line in (_init_error or "Unknown error").splitlines():
                surf = err_font.render(line[:80], True, (255, 80, 80))
                screen.blit(surf, (10, y))
                y += 22
                if y > SCREEN_HEIGHT - 30:
                    break
        else:
            board.draw_everything(screen)
            fps_list.append(frame_clock.get_fps())
            if len(fps_list) >= 100:
                average = sum(fps_list) / len(fps_list)
                # print(f"fps average:{average}")
                fps_list_whole.append(average)
                fps_list.clear()

        pygame.display.update()
        frame_clock.tick(FPS)

        await asyncio.sleep(0)


asyncio.run(main())
